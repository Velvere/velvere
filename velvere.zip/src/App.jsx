/*
Velvere - Single-file React + Tailwind e-commerce starter

How to use:
1) This is a single-file React component (default export). It uses Tailwind CSS utility classes
   for styling. To preview locally, create a new Vite + React + Tailwind project and replace src/App.jsx
   with this file's contents. See the "Deploy" section below.

2) Colors: the design uses Emerald, Black, and Gold. Tailwind classes use emerald utilities.
   Gold is used via a CSS variable (--gold: #D4AF37) to avoid editing Tailwind config.
   You can change --gold in the :root style below.

3) Products: sample products are included in the `products` array. Replace items with your real
   product names, descriptions, prices, and image URLs.

4) Shopping & Checkout: this starter implements a client-side cart and a mock checkout form.
   For real payments, integrate Stripe or another gateway during deployment (instructions below).

5) Contact info & statistics: placeholders are in the footer and a stats section — fill them later.

Deploy (simple):
- Create a Vite React app: `npm create vite@latest velvere -- --template react` then `cd velvere`.
- Install Tailwind following https://tailwindcss.com/docs/guides/vite
- Replace src/App.jsx with this file, keep index.css but ensure Tailwind directives are present.
- `npm install && npm run dev` to preview.

Payment / Checkout (recommended path):
- Use Stripe Checkout for simplest integration: create products in Stripe dashboard and call
  your backend to create an Checkout Session. Stripe docs have step-by-step (server needed).

Notes:
- This file is intentionally self-contained so you can preview layout and flows quickly.
- After deploying, you should secure forms and integrate email notifications (e.g., SendGrid) and
  add analytics (optional) like Plausible or Google Analytics (ensure privacy compliance).

Enjoy! — I'll also include a quick checklist below the app in the UI.
*/

import React, { useState } from 'react';

// Inline styles for gold because many Tailwind setups don't include a gold color by default
const GOLD = '#D4AF37';

const products = [
  {
    id: 'p1',
    name: 'Velvere Lip Silk',
    price: 18.0,
    description: 'Silky moisturizing lip balm with natural oils.',
    image: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=600&q=60',
  },
  {
    id: 'p2',
    name: 'Velvere Glow Serum',
    price: 42.0,
    description: 'Brightening facial serum with vitamin C.',
    image: 'https://images.unsplash.com/photo-1585238341979-3a6b3f9fd8a0?auto=format&fit=crop&w=600&q=60',
  },
  {
    id: 'p3',
    name: 'Velvere Satin Cleanse',
    price: 28.0,
    description: 'Gentle cleanser for daily use.',
    image: 'https://images.unsplash.com/photo-1556228720-6aa3b4d5f5f6?auto=format&fit=crop&w=600&q=60',
  },
];

export default function App() {
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderComplete, setOrderComplete] = useState(null);

  const addToCart = (product) => {
    setCart((c) => {
      const found = c.find((i) => i.id === product.id);
      if (found) {
        return c.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...c, { ...product, qty: 1 }];
    });
  };

  const updateQty = (id, qty) => {
    if (qty <= 0) {
      setCart((c) => c.filter((i) => i.id !== id));
    } else {
      setCart((c) => c.map((i) => (i.id === id ? { ...i, qty } : i)));
    }
  };

  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const handleCheckout = (form) => {
    // Mock checkout: in production, send `cart` + `form` to your backend to create an order
    const id = 'ORD-' + Math.random().toString(36).slice(2, 9).toUpperCase();
    setOrderComplete({ id, ...form, total: subtotal.toFixed(2) });
    setCart([]);
    setShowCheckout(false);
    setShowCart(false);
  };

  return (
    <div className="min-h-screen bg-white text-black antialiased">
      <style>{`:root{ --gold: ${GOLD}; }`}</style>

      {/* Header */}
      <header className="border-b border-gray-200">
        <div className="max-w-6xl mx-auto flex items-center justify-between p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full" style={{ background: 'linear-gradient(135deg,#065f46,#10b981)' }} />
            <div>
              <h1 className="text-2xl font-serif" style={{ letterSpacing: '0.06em' }}>
                <span style={{ color: 'var(--gold)' }}>Vel</span>
                <span className="text-emerald-700">vere</span>
              </h1>
              <p className="text-xs text-gray-500">Modern beauty essentials</p>
            </div>
          </div>

          <nav className="flex items-center gap-6">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="text-sm uppercase tracking-wider text-gray-700"
            >
              Shop
            </button>
            <button
              onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
              className="text-sm uppercase tracking-wider text-gray-700"
            >
              About
            </button>

            <button
              onClick={() => setShowCart(true)}
              aria-label="Open cart"
              className="relative bg-emerald-600 text-white px-3 py-2 rounded-md shadow-sm text-sm"
            >
              Cart
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-black text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">
                  {cart.reduce((n, i) => n + i.qty, 0)}
                </span>
              )}
            </button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <main className="max-w-6xl mx-auto p-6">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center py-12">
          <div>
            <h2 className="text-4xl font-extralight leading-tight mb-4">Beauty. Minimal. Modern.</h2>
            <p className="text-gray-600 mb-6">Velvere offers carefully curated essentials — clean formulas, elevated design.
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-5 py-3 border rounded-md text-sm font-medium"
              >
                Shop collection
              </button>
              <button
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-5 py-3 rounded-md text-sm font-medium"
                style={{ border: `1px solid ${GOLD}` }}
              >
                Learn more
              </button>
            </div>
          </div>
          <div className="w-full">
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img src={products[1].image} alt="hero" className="w-full h-72 object-cover" />
            </div>
          </div>
        </section>

        {/* Products */}
        <section id="products" className="py-8">
          <h3 className="text-xl font-semibold mb-6">Featured products</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((p) => (
              <div key={p.id} className="border rounded-lg p-4 flex flex-col">
                <div className="h-44 mb-4 rounded-md overflow-hidden">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium mb-1">{p.name}</h4>
                  <p className="text-sm text-gray-600 mb-3">{p.description}</p>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <div className="text-lg font-semibold">€{p.price.toFixed(2)}</div>
                    <div className="text-xs text-gray-500">Inclusive of VAT</div>
                  </div>
                  <button
                    onClick={() => addToCart(p)}
                    className="px-4 py-2 rounded-md text-sm"
                    style={{ background: 'linear-gradient(135deg,#065f46,#10b981)', color: 'white' }}
                  >
                    Add
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* About / Stats */}
        <section id="about" className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-4">About Velvere</h3>
              <p className="text-gray-600 mb-4">Velvere was born from a desire to simplify beauty. We craft essentials that feel luxurious, look beautiful on your shelf, and perform.
              </p>
              <div className="flex gap-6">
                <div>
                  <div className="text-3xl font-bold">—</div>
                  <div className="text-sm text-gray-500">Years in business</div>
                </div>
                <div>
                  <div className="text-3xl font-bold">—</div>
                  <div className="text-sm text-gray-500">Products sold</div>
                </div>
                <div>
                  <div className="text-3xl font-bold">—</div>
                  <div className="text-sm text-gray-500">5-star reviews</div>
                </div>
              </div>
            </div>
            <div>
              <div className="rounded-xl p-6 border">
                <h4 className="font-medium mb-2">Quick contact</h4>
                <p className="text-sm text-gray-600 mb-4">Fill your contact details below in the footer when ready. For now these are placeholders.</p>
                <div className="text-sm text-gray-700">Email: <span className="font-medium">hello@velvere.example</span></div>
                <div className="text-sm text-gray-700">Instagram: <span className="font-medium">@velvere</span></div>
                <div className="mt-4">
                  <button
                    onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
                    className="px-4 py-2 rounded-md text-sm"
                    style={{ border: `1px solid ${GOLD}` }}
                  >
                    Edit contact later
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer with placeholders */}
        <footer className="border-t pt-8 mt-12">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start gap-6 p-6">
            <div>
              <h5 className="font-serif text-2xl" style={{ color: 'var(--gold)' }}>Velvere</h5>
              <p className="text-sm text-gray-600">Elevated, minimal beauty.</p>
            </div>

            <div className="text-sm text-gray-600">
              <div>Contact: <span className="font-medium">[add email]</span></div>
              <div>Address: <span className="font-medium">[add address]</span></div>
            </div>

            <div className="text-sm text-gray-600">
              <div>© Velvere</div>
              <div className="mt-2">Built with care — replace texts & images with your real content.</div>
            </div>
          </div>
        </footer>
      </main>

      {/* Cart drawer */}
      {showCart && (
        <div className="fixed inset-0 z-40 flex">
          <div className="flex-1" onClick={() => setShowCart(false)} />
          <div className="w-full max-w-md bg-white border-l p-6 overflow-auto">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium">Your cart</h4>
              <button onClick={() => setShowCart(false)} className="text-sm text-gray-500">Close</button>
            </div>

            {cart.length === 0 ? (
              <div className="text-gray-500">Your cart is empty.</div>
            ) : (
              <div className="space-y-4">
                {cart.map((i) => (
                  <div key={i.id} className="flex items-center gap-4">
                    <img src={i.image} alt={i.name} className="w-16 h-16 object-cover rounded-md" />
                    <div className="flex-1">
                      <div className="font-medium">{i.name}</div>
                      <div className="text-sm text-gray-500">€{i.price.toFixed(2)}</div>
                      <div className="mt-2 flex items-center gap-2">
                        <button onClick={() => updateQty(i.id, i.qty - 1)} className="px-2 py-1 border rounded">-</button>
                        <div>{i.qty}</div>
                        <button onClick={() => updateQty(i.id, i.qty + 1)} className="px-2 py-1 border rounded">+</button>
                      </div>
                    </div>
                    <div className="text-sm">€{(i.price * i.qty).toFixed(2)}</div>
                  </div>
                ))}

                <div className="border-t pt-4 flex items-center justify-between">
                  <div className="font-medium">Subtotal</div>
                  <div className="font-semibold">€{subtotal.toFixed(2)}</div>
                </div>

                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => { setShowCheckout(true); }}
                    className="flex-1 px-4 py-3 rounded-md font-medium"
                    style={{ background: 'var(--gold)', color: 'black' }}
                  >
                    Checkout
                  </button>
                  <button onClick={() => setCart([])} className="px-4 py-3 rounded-md border">Clear</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Checkout modal */}
      {showCheckout && (
        <CheckoutModal onClose={() => setShowCheckout(false)} onComplete={handleCheckout} total={subtotal} />
      )}

      {/* Order confirmation toast */}
      {orderComplete && (
        <div className="fixed bottom-6 right-6 bg-white border p-4 rounded shadow-lg">
          <div className="font-medium">Order placed</div>
          <div className="text-sm text-gray-600">{orderComplete.id} — €{orderComplete.total}</div>
        </div>
      )}
    </div>
  );
}

function CheckoutModal({ onClose, onComplete, total }) {
  const [form, setForm] = useState({ name: '', email: '', address: '' });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative bg-white rounded-lg max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-medium">Checkout</h4>
          <button onClick={onClose} className="text-sm text-gray-500">Close</button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-sm block mb-1">Full name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full border rounded px-3 py-2" />
          </div>
          <div>
            <label className="text-sm block mb-1">Email</label>
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full border rounded px-3 py-2" />
          </div>
          <div>
            <label className="text-sm block mb-1">Address</label>
            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full border rounded px-3 py-2" />
          </div>

          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-gray-600">Total</div>
            <div className="font-semibold">€{total.toFixed(2)}</div>
          </div>

          <div className="flex gap-3 mt-4">
            <button
              onClick={() => onComplete(form)}
              className="flex-1 px-4 py-3 rounded-md font-medium"
              style={{ background: 'linear-gradient(135deg,#065f46,#10b981)', color: 'white' }}
            >
              Place order (mock)
            </button>
            <button onClick={onClose} className="px-4 py-3 rounded-md border">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
}
