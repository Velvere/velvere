# Server (Stripe example)

This simple Express server demonstrates creating a Stripe Checkout session.
Steps to use:
1. `cd server`
2. `npm install`
3. Set environment variable `STRIPE_SECRET_KEY` to your test secret key (Stripe Dashboard).
4. `node index.js`
5. Call POST /create-checkout-session with a JSON body of { items: [{ name, price, quantity }] }.
