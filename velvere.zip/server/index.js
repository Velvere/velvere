// Example Express server to create Stripe Checkout sessions.
// Replace process.env.STRIPE_SECRET_KEY with your Stripe Secret key in production.
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_replace_me');
const app = express();
app.use(express.json());

app.post('/create-checkout-session', async (req, res) => {
  try {
    const { items } = req.body; // items: [{ id, name, price, quantity }]
    const line_items = items.map(i => ({
      price_data: {
        currency: 'eur',
        product_data: { name: i.name },
        unit_amount: Math.round(i.price * 100),
      },
      quantity: i.quantity,
    }));

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: 'payment',
      success_url: 'https://velvere.example/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'https://velvere.example/cancel',
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const port = process.env.PORT || 4242;
app.listen(port, () => console.log(`Server listening on ${port}`));
