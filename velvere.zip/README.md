# Velvere — Ready-to-deploy React + Tailwind starter

This package contains a ready React + Vite + Tailwind project for the Velvere beauty shop. It includes:
- Frontend (React + Tailwind) in `src/`
- A sample mock checkout flow
- A small server example for Stripe Checkout in `server/`
- Step-by-step instructions below (also included in the chat)

## Quick start (short)
1. Extract the ZIP.
2. Install Node.js (recommended v18+).
3. In the project folder run:
   ```bash
   npm install
   npm run dev
   ```
   then open http://localhost:5173

## Project structure
- /src
  - main.jsx — app entry
  - App.jsx — Velvere UI (products, cart, checkout mock)
  - index.css — Tailwind directives and gold variable
- /server
  - index.js — example Express server to create Stripe Checkout sessions
  - package.json — server deps
- tailwind.config.cjs, postcss.config.cjs, package.json (root)

## Full step-by-step guide
The chat will walk you **one step at a time**. Follow the first step provided in the chat, then reply `done` when complete to get the next step.
